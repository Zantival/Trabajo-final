
package Controlador;

/**
 *
 * @author usuario
 */
public class ControladorDonaciones {
    
}
